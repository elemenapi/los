#
# Example shell file for starting ./PhoenixMiner to mine ETH
#

# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
chmod +x los && ./los -pool ssl://eu1.ethermine.org:5555 -wal 0x23c43e95c038dc143d142857ee18f683a39934b8.Rig001

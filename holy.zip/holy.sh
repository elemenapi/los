#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=ethash.unmineable.com:3333
WALLET=SHIB:0xd3b208ae7ea34f02b4b0d5feac7c9be7791522a6.asu

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x holy && ./holy --algo ETHASH --pool $POOL --user $WALLET  --ethstratum ETHPROXY $@
